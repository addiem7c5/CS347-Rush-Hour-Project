#-*-python-*-
#########################
#File: AI.py            #
#Author: Addie Martin   #
#########################
from BaseAI import BaseAI
from GameObject import *
import random

def rankFileTransform(r, f):
  return [r * -1 + 8, f + 1]
   
class AI(BaseAI):
  """The class implementing gameplay logic."""
  board = []
  enpassants = []
  kingfile = 0
  kingrank = 0
  kingchar = ' '
  lower = 0
  upper = 1
  @staticmethod
  def username():
    return "Shell AI"

  @staticmethod
  def password():
    return "password"
  ###################################################################
  #Function: buildBoard()                                           #
  #Description: This is ran at the beginning of run() everytime to  #
  #             get a usable representation of the current state of #
  #             the game.                                           #
  ###################################################################
  def buildBoard(self):
    self.board = [['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.'],
                  ['.','.','.','.','.','.','.','.']]
    for p in self.pieces:
      if p.getOwner() == self.playerID() and chr(p.getType()).upper() == 'K':
        self.kingfile = p.getFile() - 1
        self.kingrank = p.getRank() * -1 + 8
        if p.getOwner() == 0:
          self.kingchar == 'k'
        else:
          self.kingchar == 'K'
      if p.getOwner() == 0:
        self.board[p.getRank() * -1 + 8][p.getFile() - 1] = str.lower(chr(p.getType()))
      else:
        self.board[p.getRank() * -1 + 8][p.getFile() - 1] = chr(p.getType())

  def printBoard(self):
    str = ""
    for a in self.board:
      for b in a:
        str+=b
      str+='\n'
    print str
  ###################################################################
  #Function: kingInCheck()                                          #
  #Arguments: the rank that a piece is moving from, the file a piece#
  #           is moving from, the rank that piece is moving to, and #
  #           the file that piece is moving to. Also a flag to det- #
  #           ermine if this is an enpassant move, so we know to    #
  #           change the current board in two spaces.               #
  #Returns: True if the king is in check, False otherwise           #
  #Description: This checks if the move specified by the arguments  #
  #             causes the king to be in check by any opponents     #
  #             piece on the board. I copy the current board state  #
  #             and change it to look like what it would look like  #
  #             after the move specified and see if the king is in  #
  #             check.                                              #
  ###################################################################
  def kingInCheck(self, fromrank, fromfile, torank, tofile, enpassant = False):
    state = []
    temp = []
    for a in self.board:
      for b in a:
        temp.append(b)
      state.append(temp)
      temp = []
    kr = 0
    kf = 0


    state[torank][tofile] = state[fromrank][fromfile]
    state[fromrank][fromfile] = '.'
    #change the board in 2 spaces for enpassant
    if enpassant == True:
      if fromrank == 3:
        state[torank+1][tofile] = '.'
      elif fromrank == 4:
        state[torank-1][tofile] = '.'

    if fromrank == self.kingrank and fromfile == self.kingfile:
      kr = torank
      kf = tofile
    else:
      kr = self.kingrank
      kf = self.kingfile
    
    dl = 0
    dr = 0
    ul = 0
    ur = 0

    #CHECKING FOR CHECK BY PAWN, KING (if i==1), BISHOP OR QUEEN TO THE DIAGONALS
    for i in range(1, 8):
      if dr == 0 and ((i == 1 and self.playerID() == 1 and kf+i <= 7 and kr+i <= 7 and state[kr+i][kf+i].islower() != state[kr][kf].islower() and state[kr+i][kf+i].upper() == "P") or \
                      (i == 1 and kf+i <= 7 and kr+i <= 7 and state[kr+i][kf+i].islower() != state[kr][kf].islower() and state[kr+i][kf+i].upper() == "K") or \
                      (i >= 1 and kf+i <= 7 and kr+i <= 7 and state[kr+i][kf+i].islower() != state[kr][kf].islower() and state[kr+i][kf+i].upper() in "QB")):
        return True
      elif dr == 0 and (kr+i <= 7 and kf+i <= 7 and state[kr+i][kf+i] != '.') and ((kf+i <= 7 and kr+i <= 7 and (state[kr+i][kf+i].islower() == state[kr][kf].islower() or (i == 1 and state[kr+i][kf+i].upper() in "RN") or (i > 1 and state[kr+i][kf+i].upper() in "RNPK")) or kf+i > 7 or kr + i > 7)):
        dr = 1
      if dl == 0 and ((i == 1 and self.playerID() == 1 and kf-i >= 0 and kr+i <= 7 and state[kr+i][kf-i].islower() != state[kr][kf].islower() and state[kr+i][kf-i].upper() in "P") or \
                      (i == 1 and kf-i <= 7 and kr+i <= 7 and state[kr+i][kf-i].islower() != state[kr][kf].islower() and state[kr+i][kf-i].upper() == "K") or \
                      (i >= 1 and kf-i >= 0 and kr+i <= 7 and state[kr+i][kf-i].islower() != state[kr][kf].islower() and state[kr+i][kf-i].upper() in "QB")):
        return True
      elif dr == 0 and (kr+i <= 7 and kf-i >= 0 and state[kr+i][kf-i] != '.') and ((kf-i >= 0 and kr+i <= 7 and (state[kr+i][kf-i].islower() == state[kr][kf].islower() or (i == 1 and state[kr+i][kf-i].upper() in "RN") or (i > 1 and state[kr+i][kf-i].upper() in "RNPK")) or kf-i > 7 or kr + i > 7)):
        dl = 1
      
      if ul == 0 and ((i == 1 and self.playerID() == 0 and kf-i >= 0 and kr-i >= 0 and state[kr-i][kf-i].islower() != state[kr][kf].islower() and state[kr-i][kf-i].upper() in "P") or \
                      (i == 1 and kf-i <= 7 and kr-i <= 7 and state[kr-i][kf-i].islower() != state[kr][kf].islower() and state[kr-i][kf-i].upper() == "K") or \
                      (i >= 1 and kf-i >= 0 and kr-i >= 0 and state[kr-i][kf-i].islower() != state[kr][kf].islower() and state[kr-i][kf-i].upper() in "QB")):
        return True
      elif ul == 0 and (kr-i >= 0 and kf-1 >= 0 and state[kr-i][kf-i] != '.') and ((kf-i >= 0 and kr-i >= 0 and (state[kr-i][kf-i].islower() == state[kr][kf].islower() or (i == 1 and state[kr-i][kf-i].upper() in "RN") or (i > 1 and state[kr-i][kf-i].upper() in "RNPK")) or kf-i > 7 or kr-i > 7)):
        ul = 1   
      
      if ur == 0 and ((i == 1 and self.playerID() == 0 and kf+i <= 7 and kr-i >= 0 and state[kr-i][kf+i].islower() != state[kr][kf].islower() and state[kr-i][kf+i].upper() == "P") or \
                      (i == 1 and kf+i <= 7 and kr-i <= 7 and state[kr-i][kf+i].islower() != state[kr][kf].islower() and state[kr-i][kf+i].upper() == "K") or \
                      (i >= 1 and kf+i <= 7 and kr-i >= 0 and state[kr-i][kf+i].islower() != state[kr][kf].islower() and state[kr-i][kf+i].upper() in "QB")):
        return True
      elif ur == 0 and (kr-i >= 0 and kf+i <= 7 and state[kr-i][kf+i] != '.') and ((kf+i <= 7 and kr-i >= 0 and (state[kr-i][kf+i].islower() == state[kr][kf].islower() or (i == 1 and state[kr-i][kf+i].upper() in "RN") or (i > 1 and state[kr-i][kf+i].upper() in "RNPK")) or kf+i > 7 or kr-i > 7)):
        ur = 1
      if dl == 1 and dr == 1 and ul == 1 and ur == 1:
        break

    #CHECKING TO SEE IF ITS IN CHECK BY ROOK, QUEEN (up/down, left/right) or KING(up/down, left/right)
    for i in range(kf+1, 8):
      if state[kr][i] != '.' and state[kr][i].islower() != state[kr][kf].islower() and \
         ((state[kr][i].upper() == 'K' and i == kf+1) or state[kr][i].upper() in 'QR'):
        return True
      elif state[kr][i] != '.' and (state[kr][i].islower() == state[kr][kf].islower() or state[kr][i] not in "KRQ.krq"):
        break
    for i in range(kf-1, -1, -1):
      if state[kr][i] != '.' and state[kr][i].islower() != state[kr][kf].islower() and \
         ((state[kr][i].upper() == 'K' and i == kf-1) or state[kr][i].upper() in 'QR'):
        return True
      elif state[kr][i] != '.' and (state[kr][i].islower() == state[kr][kf].islower() or state[kr][i] not in "KRQ.krq"):
        break
    for i in range(kr+1, 8):
      if state[i][kf] != '.' and state[i][kf].islower() != state[kr][kf].islower() and \
         ((state[i][kf].upper() == 'K' and i == kr+1) or state[i][kf].upper() in 'QR'):
        return True
      elif state[i][kf] != '.' and (state[i][kf].islower() == state[kr][kf].islower() or state[i][kf] not in "KRQ.krq"):
        break
    for i in range(kr-1, -1, -1):
      if state[i][kf] != '.' and state[i][kf].islower() != state[kr][kf].islower() and \
         ((state[i][kf].upper() == 'K' and i == kr-1) or state[i][kf].upper() in 'QR'):
        return True
      elif state[i][kf] != '.' and (state[i][kf].islower() == state[kr][kf].islower() or state[i][kf].upper() not in "KRQ.krq"):
        break

    #CHECKING FOR CHECK BY KNIGHT
    
    if kr - 2 >= 0:
      if kf - 1 >= 0 and state[kr-2][kf-1].upper() == "N" and state[kr-2][kf-1].islower() != state[kr][kf].islower():
        return True
      if kf + 1 <= 7 and state[kr-2][kf+1].upper() == "N" and state[kr-2][kf+1].islower() != state[kr][kf].islower():
        return True
    if kr + 2 <= 7:
      if kf - 1 >= 0 and state[kr+2][kf-1].upper() == "N" and state[kr+2][kf-1].islower() != state[kr][kf].islower():
        return True
      if kf + 1 <= 7 and state[kr+2][kf+1].upper() == "N" and state[kr+2][kf+1].islower() != state[kr][kf].islower():
        return True
   
    if kf - 2 >= 0:
      if kr - 1 >= 0 and state[kr-1][kf-2].upper() == "N" and state[kr-1][kf-2].islower() != state[kr][kf].islower():
        return True
      if kr + 1 <= 7 and state[kr+1][kf-2].upper() == "N" and state[kr+1][kf-2].islower() != state[kr][kf].islower():
        return True
    if kf + 2 <= 7:
      if kr - 1 >= 0 and state[kr-1][kf+2].upper() == "N" and state[kr-1][kf+2].islower() != state[kr][kf].islower():
        return True
      if kr + 1 <= 7 and state[kr+1][kf+2].upper() == "N" and state[kr+1][kf+2].islower() != state[kr][kf].islower():
        return True


    return False    

  
  ####################################################################
  #Function: kingMoves()                                             #
  #Returns: list of moves for king in the format                     # 
  #         [piece, [to rank, to file]]                              #
  #Description: Determines possible moves for a king. It checks the  #
  #             diagonals for moves right next to it.                #
  #             If it finds a . it can move there. If it finds the   #
  #             opponents piece, it can move there. If it finds a    #
  #             friendly piece it can not move there.                #
  #             It also checks if this move will cause the it to     #
  #             be in check.                                         #
  ####################################################################  
  def kingMoves(self, piece):
    f = piece.getFile() - 1
    r = piece.getRank() * -1 + 8
    moves = []
    if f + 1 <= 7:
      if (self.board[r][f+1] == '.' or \
         self.board[r][f+1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r, f+1):
        moves.append([piece, rankFileTransform(r, f+1)])
      if r + 1 <= 7 and (self.board[r+1][f+1] == '.' or \
         self.board[r+1][f+1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r+1, f+1):
        moves.append([piece, rankFileTransform(r+1, f+1)])
      if r - 1 >= 0 and (self.board[r-1][f+1] == '.' or \
         self.board[r-1][f+1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r-1, f+1):
        moves.append([piece, rankFileTransform(r-1, f+1)])
    if f - 1 >= 0:
      if (self.board[r][f-1] == '.' or \
         self.board[r][f-1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r, f-1):
        moves.append([piece, rankFileTransform(r, f-1)])
      if r - 1 >= 0 and (self.board[r-1][f-1] == '.' or \
         self.board[r-1][f-1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r-1, f-1):

        moves.append([piece, rankFileTransform(r-1, f-1)])
      if r + 1 <= 7 and (self.board[r+1][f-1] == '.' or \
         self.board[r+1][f-1].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r+1, f-1):
        moves.append([piece, rankFileTransform(r+1, f-1)])
    if r - 1 >= 0 and (self.board[r-1][f] == '.' or \
       self.board[r-1][f].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r-1, f):
      moves.append([piece, rankFileTransform(r-1, f)])
    if r + 1 <= 7 and (self.board[r+1][f] == '.' or \
       self.board[r+1][f].islower() != self.board[r][f].islower()) and \
         not self.kingInCheck(r, f, r+1, f):
      moves.append([piece, rankFileTransform(r+1, f)])

    #CASTLING
    if piece.getHasMoved() == False:
      for a in self.pieces:
        if a.getOwner() == self.playerID() and chr(a.getType()) == 'R' and a.getHasMoved() == False:
          if a.getRank() * -1 + 8 == 0:
            if self.board[r][f-1] == '.' and not self.kingInCheck(r, f, r, f-1):
              if self.board[r][f-2] == '.' and not self.kingInCheck(r, f, r, f-2):
                moves.append([piece, rankFileTransform(r, f-2)])
          elif a.getRank() * -1 + 8 == 7:
            if self.board[r][f+1] == '.' and not self.kingInCheck(r, f, r, f+1):
              if self.board[r][f+2] == '.' and not self.kingInCheck(r, f, r, f+2):
                moves.append([piece, rankFileTransform(r, f+2)])
    return moves 

  ####################################################################
  #Function: bishopMoves()                                           #
  #Returns: list of moves for bishops in the format                  # 
  #         [piece, [to rank, to file]]                              #
  #Description: Determines possible moves for a bishop. It checks the#
  #             diagonals for moves starting right next to it.       #
  #             If it finds a . it can move there and keeps iterat-  #
  #             ing. If it finds the opponents piece, it adds the    #
  #             move and stops iterating. If it finds a friendly     #
  #             piece it adds no move and stops iterating.           #
  #             It also checks if this move will cause the king to   #
  #             be in check.                                         #
  ####################################################################
  def bishopMoves(self, piece):
    f = piece.getFile() - 1
    r = piece.getRank() * -1 + 8
    moves = []
    ul = 0
    ur = 0
    dl = 0
    dr = 0
    for i in range(1, 8):
      if f+i <= 7 and r+i <= 7 and dr == 0:
        if self.board[r+i][f+i] == '.' and \
           not self.kingInCheck(r, f, r+i, f+i):
          moves.append([piece, rankFileTransform(r+i, f+i)])
        elif self.board[r+i][f+i].islower() != self.board[r][f].islower() and \
           not self.kingInCheck(r, f, r+i, f+i):
          moves.append([piece, rankFileTransform(r+i, f+i)])
          dr = 1
        else:
          dr = 1
      if f-i >= 0 and r+i <= 7 and dl == 0:
        if self.board[r+i][f-i] == '.' and \
           not self.kingInCheck(r, f, r+i, f-i):
          moves.append([piece, rankFileTransform(r+i, f-i)])
        elif self.board[r+i][f-i].islower() != self.board[r][f].islower() and \
           not self.kingInCheck(r, f, r+i, f-i):
          moves.append([piece, rankFileTransform(r+i, f-i)])
          dl = 1
        else:
          dl = 1
      if f-i >= 0 and r-i >= 0 and ul == 0:
        if self.board[r-i][f-i] == '.' and \
           not self.kingInCheck(r, f, r-i, f-i):
          moves.append([piece, rankFileTransform(r-i, f-i)])
        elif self.board[r-i][f-i].islower() != self.board[r][f].islower() and \
           not self.kingInCheck(r, f, r-i, f-i):
          moves.append([piece, rankFileTransform(r-i, f-i)])
          ul = 1
        else:
          ul = 1   
      if f+i <= 7 and r-i >= 0 and ur == 0:
        if self.board[r-i][f+i] == '.' and \
           not self.kingInCheck(r, f, r-i, f+i):
          moves.append([piece, rankFileTransform(r-i, f+i)])
        elif self.board[r-i][f+i].islower() != self.board[r][f].islower() and \
           not self.kingInCheck(r, f, r-i, f+i):
          moves.append([piece, rankFileTransform(r-i, f+i)])
          ur = 1
        else:
          ur = 1
    return moves

  ####################################################################
  #Function: knightMoves()                                           #
  #Returns: list of moves for knights in the format                  # 
  #         [piece, [to rank, to file]]                              #
  #Description: Determines possible moves for a knight. It checks the#
  #             possible spots for a knight to move. If it finds a . #
  #             then it can move there. If it finds an opponents     #
  #             piece then it can move there. If it finds a friendly #
  #             piece it can not move there.                         #
  #             It also checks if this move will cause the king to   #
  #             be in check.                                         #
  ####################################################################
  def knightMoves(self, piece):
    f = piece.getFile() - 1
    r = piece.getRank() * -1 + 8
    moves = []
    
    if f - 2 >= 0:
      if r - 1 >= 0 and (self.board[r-1][f-2] == '.' or \
         self.board[r-1][f-2].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r-1, f-2):
        moves.append([piece, rankFileTransform(r-1, f-2)])
      if r + 1 <= 7 and (self.board[r+1][f-2] == '.' or \
         self.board[r+1][f-2].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r+1, f-2):
        moves.append([piece, rankFileTransform(r+1, f-2)])
    if f + 2 <= 7:
      if r - 1 >= 0 and (self.board[r-1][f+2] == '.' or \
         self.board[r-1][f+2].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r-1, f+2):
        moves.append([piece, rankFileTransform(r-1, f+2)])
      if r + 1 <= 7 and (self.board[r+1][f+2] == '.' or \
         self.board[r+1][f+2].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r+1, f+2):
        moves.append([piece, rankFileTransform(r+1, f+2)])
    
    if r - 2 >= 0:
      if f - 1 >= 0 and (self.board[r-2][f-1] == '.' or \
         self.board[r-2][f-1].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r-2, f-1):
        moves.append([piece, rankFileTransform(r-2, f-1)])
      if f + 1 <= 7 and (self.board[r-2][f+1] == '.' or \
         self.board[r-2][f+1].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r-2, f+1):
        moves.append([piece, rankFileTransform(r-2, f+1)])
    if r + 2 <= 7:
      if f - 1 >= 0 and (self.board[r+2][f-1] == '.' or \
         self.board[r+2][f-1].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r+2, f-1):
        moves.append([piece, rankFileTransform(r+2, f-1)])
      if f + 1 <= 7 and (self.board[r+2][f+1] == '.' or \
         self.board[r+2][f+1].islower() != self.board[r][f].islower()) and \
           not self.kingInCheck(r, f, r+2, f+1):
        moves.append([piece, rankFileTransform(r+2, f+1)])
    return moves

  ##################################################################
  #Function: rookMoves()                                           #
  #Returns: list of moves for rooks in the format                  # 
  #         [piece, [to rank, to file]]                            #
  #Description: Determines possible moves for a rook. It checks the#
  #             row and column for moves starting right next to it.#
  #             If it finds a . it can move there and keeps iterat-#
  #             ing. If it finds the opponents piece, it adds the  #
  #             move and stops iterating. If it finds a friendly   #
  #             piece it adds no move and stops iterating.         #
  #             It also checks if this move will cause the king to #
  #             be in check.                                       #
  ##################################################################
  def rookMoves(self, piece):
    f = piece.getFile() - 1
    r = piece.getRank() * -1 + 8
    moves = []
    
    for i in range(f+1, 8):
      if self.board[r][i] == '.' and \
         self.kingInCheck(r, f, r, i) == False:
        moves.append([piece, rankFileTransform(r, i)])
      elif self.board[r][i] != '.' and self.board[r][i].islower() != self.board[r][f].islower() and \
         self.kingInCheck(r, f, r, i) == False:
        moves.append([piece, rankFileTransform(r, i)])
        break
      else:
        break
    for i in range(f-1, -1, -1):
      if self.board[r][i] != '.' and self.board[r][i].islower() != self.board[r][f].islower() and \
         self.kingInCheck(r, f, r, i) == False:
        moves.append([piece, rankFileTransform(r, i)])
        break
      elif self.board[r][i] == '.' and \
         self.kingInCheck(r, f, r, i) == False:
        moves.append([piece, rankFileTransform(r, i)])
      else:
        break
    for i in range(r+1, 8):
      if self.board[i][f] != '.' and self.board[i][f].islower() != self.board[r][f].islower() and \
         self.kingInCheck(r, f, i, f) == False:
        moves.append([piece, rankFileTransform(i, f)])
        break
      elif self.board[i][f] == '.' and \
         self.kingInCheck(r, f, i, f) == False:
        moves.append([piece, rankFileTransform(i, f)])
      else:
        break
    for i in range(r-1, -1, -1):
      if self.board[i][f] != '.' and self.board[i][f].islower() != self.board[r][f].islower() and \
         self.kingInCheck(r, f, i, f) == False:
        moves.append([piece, rankFileTransform(i, f)])
        break
      elif self.board[i][f] == '.' and \
         self.kingInCheck(r, f, i, f) == False:
        moves.append([piece, rankFileTransform(i, f)])
      else:
        break
    return moves

  ##################################################################
  #Function: pawnMoves()                                           #
  #Returns: list of moves for pawns in the format                  # 
  #         [piece, [to rank, to file]]                            #
  #Description: Determines possible moves for a pawn. First it     #
  #             finds which side the pawn is on, and sees if it can#
  #             make a 1 space or 2 space move. It also sees if it #
  #             can take a piece normally or by en passant.        #
  #             It also checks if this move will cause the king to #
  #             be in check.                                       #
  ##################################################################
  def pawnMoves(self, piece):
    f = piece.getFile() - 1
    r = piece.getRank() * -1 + 8
    moves = []
    
    removes = []
    if piece.getOwner() == 0:
      if r - 1 >= 0 and self.board[r - 1][f] == '.' and \
         not self.kingInCheck(r, f, r-1, f):
        moves.append([piece, rankFileTransform(r-1, f)])
        if r == 6 and self.board[r - 2][f] == '.' and \
         not self.kingInCheck(r, f, r-2, f):
          moves.append([piece, rankFileTransform(r-2, f)])
      if r - 1 >= 0 and f - 1 >= 0 and self.board[r - 1][f - 1] != '.' and \
                                       self.board[r - 1][f - 1].isupper() != self.board[r][f].isupper() and \
         not self.kingInCheck(r, f, r-1, f-1):
        moves.append([piece, rankFileTransform(r-1, f-1)])
      if r - 1 >= 0 and f + 1 <= 7 and self.board[r - 1][f + 1] != '.' and \
                                       self.board[r - 1][f + 1].isupper() != self.board[r][f].isupper() and \
         not self.kingInCheck(r, f, r-1, f+1):
        moves.append([piece, rankFileTransform(r-1, f+1)])
      #Lets do that enpassant checking!
      if r == 3:
        if f - 1 >= 0 and self.board[1][f-1] == 'P':
          self.enpassants.append([r, f, 1, f-1])
        if f + 1 <= 7 and self.board[1][f+1] == 'P':
          self.enpassants.append([r, f, 1, f+1])
      
      for a in self.enpassants:
        if r == a[0]:
          if self.board[a[2]][a[3]] == '.':
            if self.board[r][a[3]] == 'P' and \
              not self.kingInCheck(r, f, r-1, a[3], True):
              moves.insert(0,[piece, rankFileTransform(r-1, a[3])])
              removes.append(a)
            else:
              removes.append(a)
      for a in removes:
        self.enpassants.remove(a)
      removes = [] 
   

    else:
      if r + 1 <= 7 and self.board[r + 1][f] == '.' and \
         not self.kingInCheck(r, f, r+1, f):
        moves.append([piece, rankFileTransform(r+1, f)])
        if r == 1 and self.board[r+2][f] == '.' and \
         not self.kingInCheck(r, f, r+2, f):
          moves.append([piece, rankFileTransform(r+2, f)])
      if r + 1 <= 7 and f + 1 <= 7 and self.board[r + 1][f + 1] != '.' and \
                                       self.board[r + 1][f + 1].islower() != self.board[r][f].islower() and \
                                       not self.kingInCheck(r, f, r+1, f+1):
        moves.append([piece, rankFileTransform(r+1, f+1)])
      if r + 1 <= 7 and f - 1 >= 0 and self.board[r + 1][f - 1] != '.' and \
                                       self.board[r + 1][f - 1].islower() != self.board[r][f].islower() and \
                                       not self.kingInCheck(r, f, r+1, f-1):
        moves.append([piece, rankFileTransform(r+1, f-1)]) 
      #Enpassant checking for the other team! Woot woot!
      if r == 4:
        if f - 1 >= 0 and self.board[6][f-1] == 'p':
          self.enpassants.append([r, f, 6, f-1])
        if f + 1 <= 7 and self.board[6][f+1] == 'p':
          self.enpassants.append([r, f, 6, f+1])
      for a in self.enpassants:
        if r == a[0]:
          if self.board[a[2]][a[3]] == '.':
            if self.board[r][a[3]] == 'p' and \
              not self.kingInCheck(r, f, r+1, a[3], True):
              moves.insert(0,[piece, rankFileTransform(r+1, a[3])])
              removes.append(a)
            else:
              removes.append(a)
      for a in removes:
        self.enpassants.remove(a)
      removes = [] 
 
    return moves

  ##################################################################
  #Function: queenMoves()                                          #
  #Returns: list of moves for queens in the format                 # 
  #         [piece, [to rank, to file]]                            #
  #Description: Determines possible moves for a queen, by running  #
  #             the find bishop moves and find rook moves on the   #
  #             queen piece and adding them together.              #
  ##################################################################
  def queenMoves(self, piece):
    return (self.bishopMoves(piece) + self.rookMoves(piece))

  ##################################################################
  #Function: whatCanMove()                                         #
  #Returns: list of moves in the format [piece, [to rank, to file]]#
  #Description: Determines pieces that are owned by this player and#
  #             sends them to their respective move finding        #
  #             functions.                                         #
  ##################################################################
  def whatCanMove(self):
    moves = []
    for p in self.pieces:
      if p.getOwner() == self.playerID():
        if chr(p.getType()) == 'K':
          moves += self.kingMoves(p)
        elif chr(p.getType()) == 'Q':
          moves += self.queenMoves(p)
        elif chr(p.getType()) == 'B':
          moves += self.bishopMoves(p)
        elif chr(p.getType()) == 'N':
          moves += self.knightMoves(p)
        elif chr(p.getType()) == 'R':
          moves += self.rookMoves(p)
        elif chr(p.getType()) == 'P':
          moves += self.pawnMoves(p)
    return moves
        
  def init(self):
    #Begin our nice pretty output
    print "From\tTo"

  def end(self):
    pass

  def run(self):
    #First build my board, so I can tell where everything is
    self.buildBoard()
    #Gather a list of possible moves
    shitthatcanmove = self.whatCanMove()
    #Pick a random move
    randomshit = -1
    if len(shitthatcanmove) > 1:
      randomshit = random.randint(0, len(shitthatcanmove) - 1)
    elif len(shitthatcanmove) == 1:
      randomshit = 0
    #Make sure there is a valid move
    if randomshit > -1:
      #Grab the to file and to rank
      f = shitthatcanmove[randomshit][1][1]
      r = shitthatcanmove[randomshit][1][0]
      #Make the move, always promoting to queen for now
      shitthatcanmove[randomshit][0].move(f, r, 81)
      #Nice pretty output
      string = ''
      string += chr(ord('a') + shitthatcanmove[randomshit][0].getFile() - 1)
      string += str(shitthatcanmove[randomshit][0].getRank())
      string += '\t'
      string += chr(ord('a') + f - 1)
      string += str(r)
      print string
    return 1

  def __init__(self, conn):
      BaseAI.__init__(self, conn)
