class ExistentialError(LookupError):
  pass
